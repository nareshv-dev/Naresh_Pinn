PINN EV Battery Phase I Report - Compressed Edition

Compile main.tex with XeLaTeX.
The abstract fits on one page. Contents, symbols, references and appendices have been compacted without changing the required 14 pt body text or margins. Figures use medium widths. The final PDF contains 55 pages, including the complete 13-page Turnitin report and its 19% overall similarity result.
