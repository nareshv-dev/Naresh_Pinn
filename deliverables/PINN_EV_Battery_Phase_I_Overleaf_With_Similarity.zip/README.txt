PINN EV Battery Phase I Report with Similarity Appendix

Upload the ZIP to Overleaf and compile main.tex with XeLaTeX.
The package includes all figures and the supplied Turnitin similarity report.
The compiled report contains 63 PDF pages, including the 19% similarity summary and the complete 13-page Turnitin evidence.
